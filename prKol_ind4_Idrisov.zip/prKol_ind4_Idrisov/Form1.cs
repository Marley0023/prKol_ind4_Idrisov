﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind4_Idrisov
{
    public partial class Form1 : Form
    {
        Hashtable catalog = new Hashtable();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string diskName = textBox1.Text;
            catalog.Add(diskName, new Hashtable());
            listBox1.Items.Add(diskName);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string selectedDisk = listBox1.SelectedItem.ToString();
            catalog.Remove(selectedDisk);
            listBox1.Items.Remove(selectedDisk);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string selectedDisk = listBox1.SelectedItem.ToString();
            Hashtable diskSongs = (Hashtable)catalog[selectedDisk];
            string songName = textBox2.Text;
            diskSongs.Add(songName, textBox3.Text);
            listBox2.Items.Add(songName);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string selectedDisk = listBox1.SelectedItem.ToString();
            Hashtable diskSongs = (Hashtable)catalog[selectedDisk];
            string selectedSong = listBox2.SelectedItem.ToString();
            diskSongs.Remove(selectedSong);
            listBox2.Items.Remove(selectedSong);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string selectedDisk = listBox1.SelectedItem.ToString();
            Hashtable diskSongs = (Hashtable)catalog[selectedDisk];
            foreach (string song in diskSongs.Keys)
            {
                listBox2.Items.Add(song);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string artistToSearch = textBox4.Text;
            foreach (Hashtable diskSongs in catalog.Values)
            {
                foreach (DictionaryEntry entry in diskSongs)
                {
                    if (entry.Value.ToString() == artistToSearch)
                    {
                        MessageBox.Show(entry.Key.ToString() + " - " + entry.Value.ToString());
                    }
                }
            }
        }
    }
}
